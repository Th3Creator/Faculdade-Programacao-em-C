#include <stdio.h>
#include <stdio.h>

int main()
{
    int M, F;
    float form1;

    printf("Digite a quantidade de homens que vao participar da pesquisa:");
    scanf("%i", &M);

    printf("\nAgora digite a quantidade de mulheres:");
    scanf("%i", &F);

    // Inicializar quatro vetores, um pra homem e outro para mulheres, de acordo com o número de participantes de cada
    int homens[M], mulheres[F], salarioH[M], salarioM[F], c, c2, c3, c4, c5, c6, c7, c8,c9, c10,c12, maior, maiorF, maioridade;
    int menor, menorF, menoridade, cont = 0, maiorsalario, maiorsalarioF,  maiorsalariogeral, idade, idadeF;

    // For idade/salário homens
    for (c = 0; c < M; c++)
    {
        printf("Digite a idade do homem %i:", c + 1);
        scanf("%i", &homens[c]);

        printf("\nDigite agora o salario dele:");
        scanf("%i", &salarioH[c]);
    }

    // For idade/salário mulheres
    for (c2 = 0; c2 < F; c2++)
    {
        printf("Digite a idade da mulher %i:", c2 + 1);
        scanf("%i", &mulheres[c2]);

        printf("\nDigite agora o salario dela:");
        scanf("%i", &salarioM[c2]);
    }

    int mediasalarialM = 0, mediasalarialF = 0, mediasalarialfinal;

    // Média dos salários, for de somatório de cada
    for (c3 = 0; c3 < M; c3++)
    {
        mediasalarialM = mediasalarialM + salarioH[c3];
    }

    for (c12 = 0; c12 < F; c12++)
    {
         mediasalarialF = mediasalarialF + salarioM[c12];
    }
    

    mediasalarialfinal = mediasalarialM + mediasalarialF / M + F;

    // Pessoa com a maior e menor idade, for de leitura e depois um if de comparação
    // Maior idade dos homens
    for (c4 = 0; c4 < M; c4++)
    {
        if (c4 == 0)
        {
            maior = homens[c4];
        }
        else if (homens[c4] > maior)
        {
            maior = homens[c4];
        }
    }

    // Maior idade das mulheres
    for (c5 = 0; c5 < F; c5++)
    {
        if (c5 == 0)
        {
            maiorF = mulheres[c5];
        }
        else if (mulheres[c5] > maiorF)
        {
            maiorF = mulheres[c5];
        }
    }

    // Maior idade geral
    if (maior > maiorF)
    {
        maioridade = maior;
    }
    else
    {
        maioridade = maiorF;
    }

    //Menor idade dos homens
    for (c6 = 0; c6 < M; c++)
    {
        if (c6 == 0)
        {
            menor = homens[c6];
        }
        else if (homens[c6] < menor)
        {
            menor = homens[c6];
        }
    }

    //Menor idade das mulheres
    for (c7 = 0; c7 < F; c7++)
    {
        if (c7 == 0)
        {
            menorF = mulheres[c7];
        }
        else if (mulheres[c7] < menorF)
        {
            menorF = mulheres[c7];
        }
    }

    //Menor idade geral
    if (menor < menorF)
    {
        menoridade = menor;
    }
    else
    {
        menoridade = menorF;
    }

    // a quantidade de homens com salário maior do que, for de leitura junto com o if
    for (c8 = 0; c8 < M; c8++)
    {
        if (salarioH[c8] >= 2500)
        {
            cont++;
        }
    }

    //a idade e o sexo da pessoa que possui o maior salário, for de leitura junto com o if+else if de print
    for (c9 = 0; c9 < M; c9++)
    {
        if (c9 == 0)
        {
            maiorsalario = homens[c9];
        }
        else if (homens[c9] > maior)
        {
            maiorsalario = homens[c9];
            idade = c9;
        }
    }

      for (c10 = 0; c10 < F; c10++)
    {
        if (c10 == 0)
        {
            maiorsalarioF = mulheres[c10];
        }
        else if (mulheres[c10] > maiorF)
        {
            maiorsalarioF = mulheres[c10];
            idadeF = c10;
        }
    }



    printf("\nA media dos salario dos habitantes e %0.f: ", mediasalarialfinal );
    printf("\nA pessoa com a maior idade e de %i anos:", maioridade);
    printf("\nA pessoa com a menor idade e de %i anos:", menoridade);
    printf("\nA quantidade de homens com o salario maior que 2500 e de: %i", cont);

     if ( maiorsalario > maiorsalarioF)
    {
        maiorsalariogeral = maiorsalario;
        printf("O maior salario e de um homem e ele possui %i anos:", homens[idade]);
    }
    else
    {
         maiorsalariogeral = maiorsalarioF; 
         printf("O maior salario e de uma mulher e ela possui %i anos:", mulheres[idadeF]);
    }

    return 0;
}